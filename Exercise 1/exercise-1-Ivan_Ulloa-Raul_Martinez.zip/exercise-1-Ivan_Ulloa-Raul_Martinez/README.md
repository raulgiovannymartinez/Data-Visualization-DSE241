Exercise 1 Instructions:

To run the visualization, open the jupyter notebook below and execute it:
	- report1_notebook.ipynb
	- The following python dependencies are required:
		pandas
		plotly.graph_objects
		plotly.subplots

Input files are located in:
	- data/olympics.csv

The visualization can be opened by executing the following HTML file:
	- final_plot.html
