DSE241
Exercise #4
Team Members: Ivan Ulloa, Raul Martinez

To create the visualization, open the jupyter notebook below and execute it:
	- Exercise4.ipynb
	- The following python dependencies are required:
		pandas
		matplotlib.pyplot
		numpy
		addEdge (included in this package)
		networkx
		plotly.graph_objects

Input files are located in:
	- ./data

Additional python packages included in:
	- ./python

The visualization can be opened by executing the following HTML file:
	- sheep_network.html